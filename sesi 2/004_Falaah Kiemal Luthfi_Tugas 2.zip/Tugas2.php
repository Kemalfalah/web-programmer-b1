<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>
     Falaah Kiemal Luthfi
  </title>
</head> 
<body>
  <div id="name">
    <h1>Falaah Kiemal Luthfi</h1>
  </div>

  <div id="social-media">
    <a href="https://www.instagram.com/kemal_falah/">instagram</a>
  </div>

  <div id="profile">
    <h1>Profile</h1>
    <p>Lulusan SMA yang sedang belajar web programing secara otodidak.</p>
  </div>

  <div id="technical-skill">
    <h1>Technical skill</h1>
    <ol>
      <li>Microsoft office</li>
      <li>Adobe Photoshop</li>
      <li>Adobe Premiere pro</li>
    </ol>
  </div>

  <div id="education">
    <h1>Education</h1>
    <ul>
      <li>SD Saruni 1</li>
      <li>SMP Majasari 1</li>
      <li>SMA 2 Pandeglang</li>
    </ul>
  </div>

  <div id="contact-me">
    <h1>Inqury</h1>
    <input type="email" placeholder="your email adress">
    <br><br>
    <textarea name="quetion" id="question" cols="30" rows="5" placeholder="your question"></textarea>
    <br>
    <input type="submit">
  </div>

</body>
</html>