1. Membuat algoritma menghitung luas dan keliling lingkaran
    Berikut adalah komponen-komponen yang digunakan dalam algoritma looping untuk menghitung luas dan keliling lingkaran:
    - Konstanta pi: Konstanta ini digunakan sebagai nilai konstan untuk menghitung luas dan keliling lingkaran. Nilai pi yang digunakan dalam contoh ini adalah 3.14
    - Variabel r: Variabel ini digunakan untuk menyimpan nilai jari-jari lingkaran yang sedang diproses pada setiap perulangan.
    - Perulangan for: Perulangan ini digunakan untuk melakukan pengulangan.
    - Rumus luas lingkaran: Rumus ini digunakan untuk menghitung luas lingkaran, yaitu L = pi * r * r.
    - Rumus keliling lingkaran: Rumus ini digunakan untuk menghitung keliling lingkaran, yaitu K = 2 * pi * r.
    - Fungsi console.log(): Fungsi ini digunakan untuk menampilkan hasil perhitungan luas dan keliling lingkaran.

2. Saya menginput jari-jari untuk menghitung luas dan keliling lingkaran:
    data: input jari-jari = 7

3. Berikut adalah langkah-langkah algoritma untuk menghitung luas dan keliling lingkaran:
    -Deklarasikan konstanta pi dengan nilai 3.14 atau 22/7 (contoh: const pi = 3.14;)
    -Deklarasikan variabel jariJari dan berikan nilai dari input pengguna
    -Hitung luas lingkaran dengan rumus: L = pi * r * r
    -Hitung keliling lingkaran dengan rumus: K = 2 * pi * r
    -Tampilkan hasil perhitungan menggunakan console.log