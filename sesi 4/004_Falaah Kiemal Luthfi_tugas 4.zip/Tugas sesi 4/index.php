<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Falaah Kiemal Luthfi</title>
</head>

<body>
    <h1>Tugas sesi 4</h1>

    <script>
        const pi = 3.14
        var r = 7

        for (var i = 0; i < r; i++) {
            var r = r;
            var luas = pi * r * r;
            var keliling = 2 * pi * r;

            console.log("Lingkaran dengan jari-jari "+ r );
            console.log("Memiliki luas "+ luas);
            console.log("Memiliki keliling "+ keliling);
        }
        
    </script>

</body>

</html>